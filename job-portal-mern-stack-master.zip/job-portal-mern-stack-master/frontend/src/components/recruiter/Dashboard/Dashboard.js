import React, { Component } from 'react';


class RecruiterDashboard extends React.Component {
    render() {
      return (
        <button className="square">
          asd2
        </button>
      );
    }
}

export default RecruiterDashboard;