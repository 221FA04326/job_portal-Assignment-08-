export const APPLICANT_LOGIN_ROUTE = '/'

export const IMAGE_PATHS = 'components/Files/Images/';

export const BASE_URL = 'http://ec2-13-52-98-111.us-west-1.compute.amazonaws.com/api';

export const S3_URL = 'https://s3-us-west-1.amazonaws.com/linkedin-cmpe273/';