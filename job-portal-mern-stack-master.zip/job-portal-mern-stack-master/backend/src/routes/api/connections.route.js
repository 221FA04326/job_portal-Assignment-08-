// 'use strict'

// const express = require('express')
// const router = express.Router()
// const auth = require('../../middlewares/authorization')

// const connectionsController = require('../../controllers/connections.controller')

// router.get('/', auth(), connectionsController.getAll)
// router.get('/mutualConnections/:userId', auth(), connectionsController.getAll)
// router.post('/addConnection/:userId', auth(), connectionsController.getAll)

// module.exports = router
